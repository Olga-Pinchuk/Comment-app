import React from 'react';
import ReactDOM from 'react-dom';
import dateTime from './date.js';
import './css/button.css';


// localStorage.clear();



const storage = localStorage.getItem('comments');




class CommentApp extends React.Component {
   constructor(){
      super();

      this.state={
         comments: [],
         newCommentName: '',
         newCommentText: ''
      };
       
      if (storage == null){
         localStorage.setItem('comments', JSON.stringify(this.state));      
      }
      else{
         this.state = JSON.parse(localStorage.getItem('comments'));
      }

      this.NameChange = this.NameChange.bind(this);

      this.TextChange = this.TextChange.bind(this);

   }

   addComment(ev) {

      ev.preventDefault();

      const commentest = this.state.comments;
       
      if (this.state.newCommentName != '' && this.state.newCommentText != '') {
         let addObj = { name: this.state.newCommentName, comment: this.state.newCommentText, date: dateTime()}
         this.state.comments.push(addObj);
      }
      else{
         alert('Оба поля должны быть заполнены!');
      }

      localStorage.setItem('comments', JSON.stringify(this.state));

      this.setState({
         commentest,
         newCommentName: '',
         newCommentText: ''
      });
   }

   delComment  (id) {
      let array = this.state.comments;
      if (id > -1) {
         array.splice(id, 1);
      }

      localStorage.setItem('comments', JSON.stringify(this.state));

      this.setState({ array });
   };


   NameChange(event) {
      this.setState({ newCommentName: event.target.value });
   }


   TextChange(event) {
      this.setState({ newCommentText: event.target.value });
   }

   render(){
      return(
         <div className = 'main-container'>
            <form>
               <input 
                  type="text" 
                  className='inputName' 
                  placeholder="Введите имя" 
                  onChange={this.NameChange}
                  value={this.state.newCommentName} 
               />
               <input 
                  type="text" 
                  className='inputText' 
                  placeholder="Введите комментарий" 
                  onChange={this.TextChange}
                  value={this.state.newCommentText} 
               />
            </form>
            
            <button 
            className="submit" type="submit"
            onClick={ev => {this.addComment(ev)}}
            >Отправить</button>
        
            <ul className = 'commentsList'>
               {
                  this.state.comments.map((commentItem, i) => {
                     return (
                        <li 
                        key = {i}
                        className = 'comments'
                        >
                           {commentItem.name + ':'}    {commentItem.comment}   {commentItem.date}
                           <button className = 'delete'
                           onClick={ev => {this.delComment(i)}}
                           >Удалить</button>
                        </li>
                     )
                  })
                  
               }
            </ul>
         </div>
      );
   }
}
ReactDOM.render(
   <CommentApp />,
   document.querySelector('.parent-div')
);
