let d = new Date()


let days = [' воскресение', ' понедельник', ' вторник', ' среда', ' четверг', ' пятница', ' суббота']

let months = [' января ', ' февраля ', ' марта ', ' апреля ', ' мая ', ' июня ', ' июля ', ' августа ', ' сентября ', ' октября ', ' ноября ', ' дикабря ']

let dayOfTheWeek = days[d.getDay()];

let Dated = d.getDate();

let month = months[d.getMonth()];

let Year = d.getFullYear();

let Hour = d.getHours();

let minut = d.getMinutes();

let seconds = d.getSeconds();

function declOfNum(number, titles) {
    let cases = [2, 0, 1, 1, 1, 2];
    return titles[(number % 100 > 4 && number % 100 < 20) ? 2 : cases[(number % 10 < 5) ? number % 10 : 5]];
}

const dateTime = function(){
    let d = new Date()

    dayOfTheWeek = days[d.getDay()];

    Dated = d.getDate();

    month = months[d.getMonth()];

    Year = d.getFullYear();

    Hour = d.getHours();

    minut = d.getMinutes();

    seconds = d.getSeconds();

    return Dated + month + Year + ' года,' + dayOfTheWeek + ', ' + Hour + declOfNum(Hour, [' час ', ' часа ', ' часов ']) + minut + declOfNum(minut, [' минута ', ' минуты ', ' минут ']) + seconds + declOfNum(seconds, [' секунда ', ' секунды ', ' секунд ']);
}

export default dateTime;